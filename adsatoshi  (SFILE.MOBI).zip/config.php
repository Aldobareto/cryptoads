<?

$UserAgent = "xxxxxxcx";
$ddg1 = "__ddg1=xxxxxxx";
$bitPTC = "bitPTC=xxxxxxxx";